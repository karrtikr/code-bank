<?php
	include "conn.php";
?>
<link rel="stylesheet" href="style.css">
<style type="text/css">
	label{
		color: black;
	}	
</style>
<div style="padding: 10px;">
	<h3>Select a query</h3>
	<form action="query.php" method="POST">
	    <p>
	      <input class="with-gap" placeholder="Enter your own query" name="query" type="text" id="test10"/>
	    </p>
		<p>
	      <input class="with-gap" name="query" type="radio" id="test1"  value="select * from students" />
	      <label for="test1">select * from students</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test2" value="select * from faculty" />
	      <label for="test2">select * from faculty</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test3"  value="select * from courses"/>
	      <label for="test3">select * from courses</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test4"  value="select * from students join courses on students.course_id=courses.course_id"/>
	      <label for="test4">select * from students join courses on students.course_id=courses.course_id</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test5"  value="select * from students order by total" />
	      <label for="test5">select * from students order by total</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test6" value="SELECT name, SUM(total) FROM students GROUP BY name" />
	      <label for="test6">select name, sum(total) from students group by name</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test7"  value="SELECT name, SUM(total) FROM students GROUP BY name order by name desc"/>
	      <label for="test7">select name, sum(total) FROM students group by name order by name desc</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test8"  value="SELECT * FROM students GROUP BY as1 HAVING as2>50"/>
	      <label for="test8">select * from students group by as1 having as2>50</label>
	    </p>
	    <p>
	      <input class="with-gap" name="query" type="radio" id="test9"  value="SELECT * FROM faculty WHERE course_id>=300"/>
	      <label for="test9">select * from faculty where course_id>=300</label>
	    </p>
	    <p>
	      <input class="with-gap" name="submit" type="submit" value="Submit"/>
	    </p>
	</form>
</div>

<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["query"])){
		$query = $_POST["query"];
		// echo $query;
		$ret = $db->query($query);
		echo "<h4>RESULT</h4>";
		while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
				print_r($row);
				echo "<hr>";
		}
	}
?>