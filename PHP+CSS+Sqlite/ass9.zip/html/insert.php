<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js"></script>
<style type="text/css">
	h4{
		text-indent: 14px;
	}
</style>
<?php
	ob_start();
	if(!isset($_GET['t_id'])){
		echo "Error: not a valid request";
	}
	else if($_SERVER['REQUEST_METHOD'] == 'POST'){
		include "conn.php";
		$sql =<<<EOF
  wxy
EOF;
$message = "Successfully created";
		switch ($_GET['t_id']) {
			case 1:
			if(isset($_POST['c_id'],$_POST['c_name'],$_POST['dept'],$_POST['f_id'])){
				$c_id = $_POST['c_id'];
				$c_name = $_POST['c_name'];
				$dept = $_POST['dept'];
				$f_id = $_POST['f_id'];
				$_SERVER['message'] = "insert INTO courses (course_id, course_name,dept,faculty_id)
  VALUES (".$c_id.",".$c_name.",".$dept.",".$f_id.")";
		$sql =<<<EOF
  INSERT INTO courses (course_id, course_name,dept,faculty_id)
  VALUES ("$c_id","$c_name","$dept","$f_id");
EOF;
}
				break;
			case 2:
			if(isset($_POST['f_name'],$_POST['dept'],$_POST['c_id'])){
				$f_name = $_POST['f_name'];
				$dept = $_POST['dept'];
				$c_id = $_POST['c_id'];
		$sql =<<<EOF
  INSERT INTO faculty (name, dept,course_id)
  VALUES ("$f_name","$dept","$c_id");
EOF;
}
				# code...
				break;
			case 3:
			if(isset($_POST['s_name'],$_POST['dept'],$_POST['c_id'],$_POST['ass1'],$_POST['ass2'],$_POST['quiz'],$_POST['tot'],$_POST['per'],$_POST['grade'])){
				$s_name = $_POST['s_name'];
				$dept = $_POST['dept'];
				$c_id = $_POST['c_id'];
				$ass1 = $_POST['ass1'];
				$ass2 = $_POST['ass2'];
				$quiz = $_POST['quiz'];
				$tot = $_POST['tot'];
				$per = $_POST['per'];
				$grade = $_POST['grade'];
		$sql =<<<EOF
  INSERT INTO students (name, dept,course_id,as1,as2,quiz,total,percentage,grade)
  VALUES ("$s_name","$dept","$c_id","$ass1","$ass2","$quiz","$tot","$per","$grade");
EOF;
}
				break;
			default:
				echo "Invalid request<br>";
				break;
		}
		$ret = $db->exec($sql);
		if(!$ret){
		  echo $db->lastErrorMsg();
		} else {
			$message = $_SERVER['message'];
			echo $message;
			// echo "<script type='text/javascript'>alert('$message');</script>";
		    header("Location: index.php");
		}
		$db->close();
	} else{
		$table_id = $_GET['t_id'];
		switch ($table_id) {
		    case 1:
		        echo '
		        <h4>New course</h4>
	    <div class="row">
	    <form class="col s12" action="insert.php?t_id=1" method="POST">
	    <div class="row">
	        <div class="input-field col s12">
	          <input id="c_id" name = "c_id" type="number" class="validate" required>
	          <label for="c_id">Course ID</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="c_name" name = "c_name" type="text" class="validate" required>
	          <label for="c_name">Course Name</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="Department" name = "dept" type="text" class="validate" required>
	          <label for="Department">Department</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="f_id" name = "f_id" type="number" class="validate" required>
	          <label for="f_id">Faculty ID</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="submit" type="submit" class = "validate">
	        </div>
	      </div>
	    </form>
	  </div>';
		        break;
		    case 2:
		        echo '
		        <h4>New Faculty</h4>
	    <div class="row">
	    <form class="col s12" action="insert.php?t_id=2" method="POST">
	    <div class="row">
	        <div class="input-field col s12">
	          <input id="f_name" name = "f_name" type="text" class="validate" required>
	          <label for="f_name">Faculty Name</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="Department" name = "dept" type="text" class="validate" required>
	          <label for="Department">Department</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="c_id" name = "c_id" type="number" class="validate" required>
	          <label for="c_id">Course ID</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="submit" type="submit" class = "validate">
	        </div>
	      </div>
	    </form>
	  </div>';
		        break;
		    case 3:
		        echo '
		        <h4>New Student details</h4>
	    <div class="row">
	    <form class="col s12" action="insert.php?t_id=3" method="POST">
	    <div class="row">
	        <div class="input-field col s12">
	          <input id="s_name" name = "s_name" type="text" class="validate" required>
	          <label for="s_name">Student Name</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="Department" name = "dept" type="text" class="validate" required>
	          <label for="Department">Department</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="c_id" name = "c_id" type="number" class="validate" required>
	          <label for="c_id">Course ID</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="ass1" name = "ass1" type="number" class="validate" required>
	          <label for="ass1">Ass 1</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="ass2" name = "ass2" type="number" class="validate" required>
	          <label for="ass2">Ass 2</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="quiz" name = "quiz" type="number" class="validate" required>
	          <label for="quiz">Quiz</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="tot" name = "tot" type="number" class="validate" required>
	          <label for="tot">Total</label>
	        </div>
	      </div>
  	      <div class="row">
	        <div class="input-field col s12">
	          <input id="per" name = "per" type="number" class="validate" required>
	          <label for="per">Percentage</label>
	        </div>
	      </div>
  	      <div class="row">
	        <div class="input-field col s12">
	          <input id="grade" name = "grade" type="text" class="validate" required>
	          <label for="grade">Grade</label>
	        </div>
	      </div>
	      <div class="row">
	        <div class="input-field col s12">
	          <input id="submit" type="submit" class = "validate">
	        </div>
	      </div>
	    </form>
	  </div>';
		        break;
		    default:
		        echo "Not a valid table number";
		}
	}
?>

