<?php
	include "conn.php";
  $c_id = "446";
  $c_name = "hello";
  $dept = "cse";
  $f_id = "8";
	$sql =<<<EOF
  INSERT INTO courses (course_id, course_name,dept,faculty_id)
  VALUES ("$c_id","$c_name","$dept","$f_id");
EOF;
	$ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Records created successfully\n";
   }
   $db->close();
?>