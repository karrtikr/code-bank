<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
<link rel="stylesheet" href="style.css">
<h2><u>Database management system</u></h2>
<div class="row">
      <div class="col s12">
        <div class="card-panel yellow">
          <h4 style="text-indent: 0px; color: navy; text-decoration: none;">Description</h4>          
          <span style="color: black; font-size: 20px;">Welcome to database management system. Here you can view all data in a tabular form. You can insert new data as rows. Lastly, you can perform some queries. Just follow the links :)
          </span>
        </div>
      </div>
    </div>
<?php
	include "conn.php";
	// Display course table
	echo "<h4>Course details</h4>";
	$sql =<<<EOF
      SELECT * FROM courses;
EOF;

   $ret = $db->query($sql);
   echo "<br>";
   echo "<table class=\"bordered striped centered responsive-table\">
   		<thead>
			<tr>
				<th data-field=\"cid\">Course ID</th>
				<th data-field=\"name\">Course Name</th>
				<th data-field=\"dept\">Department</th>
				<th data-field=\"fid\">Faculty ID</th>
			</tr>
        </thead>
        <tbody>";
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
   		// print_r($row);
   		echo "<tr>
	            <td>".$row['course_id']."</td>
	            <td>".$row['course_name']."</td>
	            <td>".$row['dept']."</td>
	            <td>".$row['faculty_id']."</td>
          	</tr>";
   }
   echo "</tbody>
      </table><br>
   <a class=\"waves-effect waves-light btn\" href='insert.php?t_id=1'>Insert</a>
   <a class=\"waves-effect waves-light btn\" href='query.php'>Query</a>";
   //Ends
   //Display faculty table
   echo "<h4>Faculty details</h4>";
   $sql =<<<EOF
      SELECT * FROM faculty;
EOF;

   $ret = $db->query($sql);
   echo "<br>";
   echo "<table class=\"bordered striped centered responsive-table\">
   		<thead>
			<tr>
				<th data-field=\"fid\">Faculty ID</th>
				<th data-field=\"name\">Name</th>
				<th data-field=\"dept\">Department</th>
				<th data-field=\"cid\">Course ID</th>
			</tr>
        </thead>
        <tbody>";
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
   		// print_r($row);
   		echo "<tr>
	            <td>".$row['id']."</td>
	            <td>".$row['name']."</td>
	            <td>".$row['dept']."</td>
	            <td>".$row['course_id']."</td>
          	</tr>";
   }
   echo "</tbody>
      </table><br>
   <a class=\"waves-effect waves-light btn\" href='insert.php?t_id=2'>Insert</a>
   <a class=\"waves-effect waves-light btn\" href='query.php'>Query</a>";
   //Display students table
   echo "<h4>Students details</h4>";
   $sql =<<<EOF
      SELECT * FROM students;
EOF;

   $ret = $db->query($sql);
   echo "<br>";
   echo "<table class=\"bordered striped centered responsive-table\">
   		<thead>
			<tr>
				<th data-field=\"sid\">Student ID</th>
				<th data-field=\"name\">Name</th>
				<th data-field=\"dept\">Department</th>
				<th data-field=\"cid\">Course ID</th>
				<th data-field=\"ass1\">Ass 1</th>
				<th data-field=\"ass2\">Ass 2</th>
				<th data-field=\"quiz\">Quiz</th>
				<th data-field=\"tot\">Total</th>
				<th data-field=\"per\">Percentage</th>
				<th data-field=\"grade\">Grade</th>
			</tr>
        </thead>
        <tbody>";
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
   		// print_r($row);
   		echo "<tr>
	            <td>".$row['student_id']."</td>
	            <td>".$row['name']."</td>
	            <td>".$row['dept']."</td>
	            <td>".$row['course_id']."</td>
	            <td>".$row['as1']."</td>
	            <td>".$row['as2']."</td>
	            <td>".$row['quiz']."</td>
	            <td>".$row['total']."</td>
	            <td>".$row['percentage']."</td>
	            <td>".$row['grade']."</td>
          	</tr>";
   }
   echo "</tbody>
      </table><br>
   <a class=\"waves-effect waves-light btn\" href='insert.php?t_id=3'>Insert</a>
   <a class=\"waves-effect waves-light btn\" href='query.php'>Query</a><br><br>";      
   $db->close();
?>