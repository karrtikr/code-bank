function r=dice1(total)
	s=0;
	for sample=1:total
    	x=rand(1);
    	if(x<1/6)
    		s=s+1;
    	elseif(x<2/6)
    		s=s+2;
    	elseif(x<3/6)
    		s=s+3;
    	elseif(x<4/6)
    		s=s+4;
    	elseif(x<5/6)
    		s=s+5;
    	else
    		s=s+6;
    	endif
    endfor
    r=s/total;
endfunction

function r=dice2(total)
	s=0;
	for sample=1:total
    	x=rand(1);
    	if(x<13/60)
    		s=s+5;
    	elseif(x<26/60)
    		s=s+6;
    	elseif(x<23/40)
    		s=s+1;
    	elseif(x<43/60)
    		s=s+2;
    	elseif(x<103/120)
    		s=s+3;
    	else
    		s=s+4;
    	endif
    endfor
    r=s/total;
endfunction

function r=dice3(total)
	s=0;
	for sample=1:total
    	x=rand(1);
    	if(x<4/15)
    		s=s+5;
    	elseif(x<8/15)
    		s=s+6;
    	elseif(x<13/20)
    		s=s+1;
    	elseif(x<23/30)
    		s=s+2;
    	elseif(x<53/60)
    		s=s+3;
    	else
    		s=s+4;
    	endif
    endfor
    r=s/total;
endfunction

n = 1e1;
f=fopen("output.dat","w");
printf("x\t");
fprintf(f,"x\t");
while (n < 1e5)
  fprintf(f,"%d\t%d\t",n,n);
  printf("%d\t%d\t",n,n);
  n *= 10;
endwhile
n = 1e1;
fprintf(f,"\n");
printf("\n");
printf("Dice1\t");
fprintf(f,"Dice1\t");
while (n < 1e5)
  fprintf(f,"%.4f\t%.4f\t",dice1(n),dice1(n));
  printf("%.4f\t%.4f\t",dice1(n),dice1(n));
  n *= 10;
endwhile
n = 1e1;
fprintf(f,"\n");
printf("\n");
printf("Dice2\t");
fprintf(f,"Dice2\t");
while (n < 1e5)
  fprintf(f,"%.4f\t%.4f\t",dice2(n),dice2(n));
  printf("%.4f\t%.4f\t",dice2(n),dice2(n));
  n *= 10;
endwhile
n = 1e1;
fprintf(f,"\n");
printf("\n");
printf("Dice3\t");
fprintf(f,"Dice3\t");
while (n < 1e5)
  fprintf(f,"%.4f\t%.4f\t",dice3(n),dice3(n));
  printf("%.4f\t%.4f\t",dice3(n),dice3(n));
  n *= 10;
endwhile
fprintf(f,"\n");
printf("\n");