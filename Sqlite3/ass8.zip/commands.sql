create table faculty (id integer not null primary key, name varchar(50) not null, dept varchar(50) not null, course_id integer);
create table courses (course_id integer not null primary key, course_name varchar(50) not null, dept varchar(50) not null,faculty_id integer not null, foreign key (faculty_id) references faculty(id));
create table students (student_id integer not null primary key, name varchar(50) not null, dept varchar(50) not null, course_id integer, as1 integer, as2 integer, quiz integer, total integer, percentage double, grade varchar(50));
.mode column
.separator ","
.header on
.import yo.csv students
.import faculty.csv faculty
.import course.csv courses
select * from faculty;
select * from courses;
select * from students;
update students set total=as1+as2+quiz;
update students set percentage=total/3;
update students set grade='E' where (percentage>=40);
update students set grade='D' where (percentage>=60);
update students set grade='C' where (percentage>=70);
update students set grade='B' where (percentage>=80);
update students set grade='A' where (percentage>=90);
select * from students;
select * from students join courses on students.course_id=courses.course_id;
.out out.txt
select * from students;
select * from students join courses on students.course_id=courses.course_id;
select * from students order by total;
